package customchat.util;

public class RecordNotFoundException extends DataBaseException {
  public RecordNotFoundException(String s) {
	super(s);
  }  
}
