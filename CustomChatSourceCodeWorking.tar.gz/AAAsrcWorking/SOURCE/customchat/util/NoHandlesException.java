package customchat.util;

public class NoHandlesException extends DataBaseException {
	public NoHandlesException(String s) {
	  super(s);
	}
}
