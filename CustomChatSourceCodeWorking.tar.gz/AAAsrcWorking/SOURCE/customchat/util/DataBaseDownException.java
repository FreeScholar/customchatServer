package customchat.util;

public class DataBaseDownException extends DataBaseException {
  public DataBaseDownException(String s) {
	super(s);
  }  
}
