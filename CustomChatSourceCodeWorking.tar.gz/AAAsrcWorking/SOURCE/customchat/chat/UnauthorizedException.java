package customchat.chat;

public class UnauthorizedException extends ChatException {
  public UnauthorizedException(String s) {
	super(s);
  }  
}
