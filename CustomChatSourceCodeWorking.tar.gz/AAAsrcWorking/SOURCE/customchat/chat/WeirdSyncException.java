package customchat.chat;

class WeirdSyncException extends ChatException{
  WeirdSyncException(String s) {
	super(s);
  }  
}
