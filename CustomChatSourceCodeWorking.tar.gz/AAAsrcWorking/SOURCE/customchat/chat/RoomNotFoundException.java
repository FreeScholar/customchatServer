package customchat.chat;

class RoomNotFoundException extends ChatException {
  RoomNotFoundException(String s) {
	super(s);
  }  
}
