package customchat.chat;

public class InvalidHandleException extends ChatException {
  public InvalidHandleException(String s){
	super(s);
  }  
}
