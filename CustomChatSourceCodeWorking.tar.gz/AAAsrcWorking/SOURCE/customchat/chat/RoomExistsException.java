package customchat.chat;

class RoomExistsException extends ChatException{
  RoomExistsException(String s) {
	super(s);
  }  
}
