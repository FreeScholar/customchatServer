package customchat.chat;

class InvalidRoomPassException extends ChatException {
  InvalidRoomPassException(String s){
	super(s);
  }  
}
