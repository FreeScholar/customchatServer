package customchat.chat;

class AlreadyInRoomException extends ChatException {
  AlreadyInRoomException(){ super(); }  
}
