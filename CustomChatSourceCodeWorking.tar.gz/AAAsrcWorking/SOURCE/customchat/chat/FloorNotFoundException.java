package customchat.chat;

class FloorNotFoundException extends ChatException {
  FloorNotFoundException(String s) {
	super(s);
  }  
}
