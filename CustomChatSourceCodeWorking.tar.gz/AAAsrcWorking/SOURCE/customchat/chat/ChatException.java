package customchat.chat;

public class ChatException extends Exception {

  public ChatException() {
	super();
  }  
  public ChatException(String s) {
	  super(s);
  }  
}
